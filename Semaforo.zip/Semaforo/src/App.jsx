import TrafficLight from "./componentes/TrafficLight"

export default function App(){
    return(
        <TrafficLight/>
    )
}